import p1 from "../assets/sadesati/basic.webp"
import p2 from "../assets/sadesati/plus.webp"
export const productArray = [
    {
        id: 1,
        name: "3 मुखी रुद्राक्ष",
        desc: "3 मुखी रुद्राक्ष आत्मबल को बढ़ाने, पिछले कर्मों से मुक्ति दिलाने और आत्मविश्वास में वृद्धि के लिए उपयोगी होता है। यह मानसिक तनाव को कम करता है और आत्मिक शांति प्रदान करता है।",
        price: 791,
        img: "https://m.media-amazon.com/images/I/51o1UIXcsmS._AC_UF894,1000_QL80_.jpg"
    },
    {
        id: 2,
        name: "5 मुखी रुद्राक्ष",
        desc: "5 मुखी रुद्राक्ष बुद्धि, स्वास्थ्य और शांति के लिए जाना जाता है। यह रक्तचाप को नियंत्रित करता है और विद्यार्थियों व साधकों के लिए विशेष लाभकारी होता है।",
        price: 998,
        img: "https://m.media-amazon.com/images/I/51ok9mt1jcL._AC_UY1100_.jpg"
    }
];